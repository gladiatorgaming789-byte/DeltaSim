import { gb as R6, hb as R7 } from "./c-ZEHUSSXN.js";
import { a as R8, c as R9, e as RR, l as RY } from "./c-7Q4J33FN.js";
var RM = {};
R9(RM, {
  obj_actor_tenna: () => RZ,
  obj_animator_complex: () => Rf,
  obj_astream: () => Rp,
  obj_attack_yellow_reticle_bullet: () => Rm,
  obj_bloxer_enemy: () => RV,
  obj_bramble: () => Rl,
  obj_castle_tutorial: () => RU,
  obj_caterpillar_dash: () => RA,
  obj_ch2_city_berdly: () => Rw,
  obj_ch4_PDC06A: () => Ra,
  obj_ch4_PDC06B: () => Rz,
  obj_ch5_DW19A: () => RI,
  obj_ch5_DW29: () => RS,
  obj_ch5_DW29_power_up_flowery: () => RW,
  obj_ch5_DW40: () => RE,
  obj_ch5_DW45: () => Rq,
  obj_ch5_LW02: () => RL,
  obj_ch5_LW07: () => Rv,
  obj_ch5_LWF01: () => RT,
  obj_church_entrance_festival: () => RN,
  obj_climb_climbable: () => RX,
  obj_climb_cloudspeedcontroller: () => Y1,
  obj_climb_kris: () => Y3,
  obj_climb_susie: () => Y5,
  obj_climb_susie_controller: () => Y7,
  obj_climb_vinecuttable: () => Y9,
  obj_controller_dw_city_big_2: () => YY,
  obj_custommenu: () => YO,
  obj_cutscene_delaycmd: () => YQ,
  obj_cutscene_messagecmd: () => YB,
  obj_darkdoor: () => YK,
  obj_darkfruit_tree_plat: () => YD,
  obj_darkslide: () => Yh,
  obj_darkslide_new: () => Yy,
  obj_dashmode_trigger: () => Yo,
  obj_diamondenemy: () => Yj,
  obj_dojofx: () => YF,
  obj_dw_cliff_kawkawdash: () => Yn,
  obj_dw_cliffs_tallgrass: () => YH,
  obj_dw_dogplatforming: () => YC,
  obj_dw_fcastle_bounce_3: () => YJ,
  obj_dw_fcastle_flowerclimb: () => Yb,
  obj_dw_fcastle_flowery: () => Ye,
  obj_dw_fcastle_green_checkpoint: () => YP,
  obj_dw_fcastle_orange_gauntlet: () => Yg,
  obj_dw_fcastle_seth_encounter: () => Yu,
  obj_dw_fcastle_top_ascent: () => Yr,
  obj_dw_fcastle_top_challenge: () => YG,
  obj_dw_fcastle_top_descent: () => M0,
  obj_dw_fcastle_top_staircase_1: () => M2,
  obj_dw_fcastle_top_staircase_2: () => M4,
  obj_dw_fcastle_ultradash: () => M6,
  obj_dw_fcastle_yellowblue: () => M8,
  obj_dw_flowery_tree: () => MR,
  obj_dw_garden_aquadash_plat: () => MM,
  obj_dw_garden_aquaplatforming: () => MZ,
  obj_dw_garden_enemyrush: () => Mf,
  obj_dw_leave: () => Mp,
  obj_dw_leave_flowercastle: () => Mm,
  obj_dw_leave_flowery: () => MV,
  obj_elevator_warp: () => Ml,
  obj_elnina_lanino_rematch_controller: () => MU,
  obj_flowery_act_menu_heart: () => MA,
  obj_flowery_marker: () => Mw,
  obj_flowerybox_parent: () => Ma,
  obj_glowtile_new: () => Mz,
  obj_headhathy: () => MI,
  obj_heartenemy: () => MS,
  obj_heartmarker: () => MW,
  obj_heightfloor_changer: () => ME,
  obj_heronoelle: () => Mq,
  obj_id: () => ML,
  obj_index: () => Mv,
  obj_interactablesolid: () => MT,
  obj_jackenstein_enemy: () => MN,
  obj_jigsawryenemy: () => MX,
  obj_king_boss: () => O1,
  obj_kris_headobj: () => O3,
  obj_lancerboss: () => O5,
  obj_lancerboss2: () => O7,
  obj_lancerboss3: () => O9,
  obj_mainchara: () => OY,
  obj_mainchara_dash: () => OO,
  obj_maus_enemy: () => OQ,
  obj_move_actor: () => OB,
  obj_npc_cafe: () => OK,
  obj_npc_castle_cafe: () => OD,
  obj_npc_castle_cliff: () => Oh,
  obj_npc_castle_door: () => Oy,
  obj_npc_castle_town_mizzle: () => Oo,
  obj_npc_dojo: () => Oj,
  obj_npc_dumpster: () => OF,
  obj_npc_hammerguy: () => On,
  obj_npc_rabbits: () => OH,
  obj_npc_room: () => OC,
  obj_npc_sign: () => OJ,
  obj_npc_tasquemanager: () => Ob,
  obj_omawaroid_enemy: () => Oe,
  obj_onion_event: () => OP,
  obj_panfancy: () => Og,
  obj_papergrass: () => Ou,
  obj_parallax_cliffs: () => Or,
  obj_pink_spotlight: () => OG,
  obj_pinwheel_windspeed: () => Z0,
  obj_plat_action_blocker: () => Z2,
  obj_plat_action_release_trigger: () => Z4,
  obj_plat_attacktrigger: () => Z6,
  obj_plat_blueflower: () => Z8,
  obj_plat_bulletblue_yellowhat: () => ZR,
  obj_plat_camera: () => ZM,
  obj_plat_combatstarter: () => ZZ,
  obj_plat_conspiracy_new: () => Zf,
  obj_plat_conspiracywall: () => Zp,
  obj_plat_dialogue_sequencer: () => Zm,
  obj_plat_enm_aqua_bouncer: () => ZV,
  obj_plat_enm_aqua_gold: () => Zl,
  obj_plat_enm_aqua_small: () => ZU,
  obj_plat_enm_aqua_sword: () => ZA,
  obj_plat_enm_bigtome: () => Zw,
  obj_plat_enm_glovespawner: () => Za,
  obj_plat_enm_glovespawner_directional: () => Zz,
  obj_plat_enm_yellow_punishmentgun: () => ZI,
  obj_plat_enm_yellow_ufohat: () => ZS,
  obj_plat_finalflowery: () => ZW,
  obj_plat_floortex: () => ZE,
  obj_plat_floortex_FLOOR: () => Zq,
  obj_plat_follower: () => ZL,
  obj_plat_fusumawall: () => Zv,
  obj_plat_game: () => ZT,
  obj_plat_hanging_key: () => ZN,
  obj_plat_lantern: () => ZX,
  obj_plat_loopboundary: () => Q1,
  obj_plat_movemarker: () => Q3,
  obj_plat_orangewall: () => Q5,
  obj_plat_pinatabell: () => Q7,
  obj_plat_pinatabell_pink: () => Q9,
  obj_plat_player: () => QY,
  obj_plat_playerheart: () => QO,
  obj_plat_sequence_marker: () => QQ,
  obj_plat_shinobeetle: () => QB,
  obj_plat_slope: () => QK,
  obj_plat_slope_runner: () => QD,
  obj_plat_stringed_object: () => Qh,
  obj_plat_susieaxe_hbx: () => Qy,
  obj_plat_text_at_bottom_zone: () => Qo,
  obj_plat_toyrope: () => Qj,
  obj_plat_wind: () => QF,
  obj_platswap: () => Qn,
  obj_platswap_statue: () => QH,
  obj_poppup_enemy: () => QC,
  obj_rabbick_enemy: () => QJ,
  obj_room_alphysclass: () => Qb,
  obj_room_castle_dojo: () => Qe,
  obj_room_castle_front_race: () => QP,
  obj_room_castle_front_racer: () => Qg,
  obj_room_castle_kris: () => Qu,
  obj_room_castle_music: () => Qr,
  obj_room_castle_ralsei: () => QG,
  obj_room_castle_susie: () => f0,
  obj_room_castle_tv_kikky: () => f2,
  obj_room_castle_tv_mike: () => f4,
  obj_room_castle_tv_rhythm: () => f6,
  obj_room_krisroom: () => f8,
  obj_room_torbathroom: () => fR,
  obj_room_torhouse: () => fM,
  obj_room_town_church: () => fZ,
  obj_room_town_krisyard: () => ff,
  obj_room_town_mid_diner: () => fp,
  obj_room_town_school: () => fm,
  obj_rotating_tower_controller_new: () => fV,
  obj_scissor_flower_chaser_scissor: () => fl,
  obj_scissordancer: () => fU,
  obj_shinobeetle_star: () => fA,
  obj_smallcheckers_enemy: () => fw,
  obj_smalldough: () => fa,
  obj_soliddark: () => fz,
  obj_solidenemy: () => fI,
  obj_solidenemy_2: () => fS,
  obj_sourdough: () => fW,
  obj_spwnY: () => fE,
  obj_starwalker_offswitch: () => fq,
  obj_stickto: () => fL,
  obj_sticky_example: () => fv,
  obj_sunshadows: () => fT,
  obj_susieenemy: () => fN,
  obj_swatchling_enemy: () => fX,
  obj_swordhitbox: () => B1,
  obj_tasque_enemy: () => B3,
  obj_tm_quiz_result: () => B5,
  obj_torigate: () => B7,
  obj_towery_orbiter: () => B9,
  obj_town_church_rudy: () => BY,
  obj_town_mid_conbini: () => BO,
  obj_town_mid_doors: () => BQ,
  obj_town_mid_ferris: () => BB,
  obj_town_mid_ferris_w: () => BK,
  obj_town_mid_sans: () => BD,
  obj_town_mid_sans_w: () => Bh,
  obj_town_mid_teacup: () => By,
  obj_town_mid_temmie: () => Bo,
  obj_town_north: () => Bj,
  obj_town_north_asgore: () => BF,
  obj_town_north_catty_house: () => Bn,
  obj_town_north_napstablook: () => BH,
  obj_town_south_dunk_tank: () => BC,
  obj_town_south_strength: () => BJ,
  obj_town_south_tako: () => Bb,
  obj_town_w_shining: () => Be,
  obj_virovirokun_enemy: () => BP,
  obj_werewerewire_enemy: () => Bg,
  obj_werewerewire_laserbullet: () => Bu,
  obj_werewire_enemy: () => Br,
  obj_yheart_shot: () => BG,
});
RY();
var RO = class i4 extends R6 {};
R8(RO, "obj_actor_tenna");
RR(RO, "kinds", R7("obj_actor_tenna", R6));
var RZ = RO;
var RQ = class i5 extends R6 {};
R8(RQ, "obj_animator_complex");
RR(RQ, "kinds", R7("obj_animator_complex", R6));
var Rf = RQ;
var RB = class i6 extends R6 {};
R8(RB, "obj_astream");
RR(RB, "kinds", R7("obj_astream", R6));
var Rp = RB;
var RK = class i7 extends R6 {};
R8(RK, "obj_attack_yellow_reticle_bullet");
RR(RK, "kinds", R7("obj_attack_yellow_reticle_bullet", R6));
var Rm = RK;
var RD = class i8 extends R6 {};
R8(RD, "obj_bloxer_enemy");
RR(RD, "kinds", R7("obj_bloxer_enemy", R6));
var RV = RD;
var Rh = class i9 extends R6 {};
R8(Rh, "obj_bramble");
RR(Rh, "kinds", R7("obj_bramble", R6));
var Rl = Rh;
var Ry = class iR extends R6 {};
R8(Ry, "obj_castle_tutorial");
RR(Ry, "kinds", R7("obj_castle_tutorial", R6));
var RU = Ry;
var Ro = class iY extends R6 {};
R8(Ro, "obj_caterpillar_dash");
RR(Ro, "kinds", R7("obj_caterpillar_dash", R6));
var RA = Ro;
var Rj = class iM extends R6 {};
R8(Rj, "obj_ch2_city_berdly");
RR(Rj, "kinds", R7("obj_ch2_city_berdly", R6));
var Rw = Rj;
var RF = class iO extends R6 {};
R8(RF, "obj_ch4_PDC06A");
RR(RF, "kinds", R7("obj_ch4_PDC06A", R6));
var Ra = RF;
var Rn = class iZ extends R6 {};
R8(Rn, "obj_ch4_PDC06B");
RR(Rn, "kinds", R7("obj_ch4_PDC06B", R6));
var Rz = Rn;
var RH = class iQ extends R6 {};
R8(RH, "obj_ch5_DW19A");
RR(RH, "kinds", R7("obj_ch5_DW19A", R6));
var RI = RH;
var RC = class iB extends R6 {};
R8(RC, "obj_ch5_DW29");
RR(RC, "kinds", R7("obj_ch5_DW29", R6));
var RS = RC;
var RJ = class ip extends R6 {};
R8(RJ, "obj_ch5_DW29_power_up_flowery");
RR(RJ, "kinds", R7("obj_ch5_DW29_power_up_flowery", R6));
var RW = RJ;
var Rb = class iK extends R6 {};
R8(Rb, "obj_ch5_DW40");
RR(Rb, "kinds", R7("obj_ch5_DW40", R6));
var RE = Rb;
var Re = class im extends R6 {};
R8(Re, "obj_ch5_DW45");
RR(Re, "kinds", R7("obj_ch5_DW45", R6));
var Rq = Re;
var RP = class iD extends R6 {};
R8(RP, "obj_ch5_LW02");
RR(RP, "kinds", R7("obj_ch5_LW02", R6));
var RL = RP;
var Rg = class iV extends R6 {};
R8(Rg, "obj_ch5_LW07");
RR(Rg, "kinds", R7("obj_ch5_LW07", R6));
var Rv = Rg;
var Ru = class ih extends R6 {};
R8(Ru, "obj_ch5_LWF01");
RR(Ru, "kinds", R7("obj_ch5_LWF01", R6));
var RT = Ru;
var Rr = class il extends R6 {};
R8(Rr, "obj_church_entrance_festival");
RR(Rr, "kinds", R7("obj_church_entrance_festival", R6));
var RN = Rr;
var RG = class iy extends R6 {};
R8(RG, "obj_climb_climbable");
RR(RG, "kinds", R7("obj_climb_climbable", R6));
var RX = RG;
var Y0 = class iU extends R6 {};
R8(Y0, "obj_climb_cloudspeedcontroller");
RR(Y0, "kinds", R7("obj_climb_cloudspeedcontroller", R6));
var Y1 = Y0;
var Y2 = class io extends R6 {};
R8(Y2, "obj_climb_kris");
RR(Y2, "kinds", R7("obj_climb_kris", R6));
var Y3 = Y2;
var Y4 = class iA extends R6 {};
R8(Y4, "obj_climb_susie");
RR(Y4, "kinds", R7("obj_climb_susie", R6));
var Y5 = Y4;
var Y6 = class ij extends R6 {};
R8(Y6, "obj_climb_susie_controller");
RR(Y6, "kinds", R7("obj_climb_susie_controller", R6));
var Y7 = Y6;
var Y8 = class iw extends R6 {};
R8(Y8, "obj_climb_vinecuttable");
RR(Y8, "kinds", R7("obj_climb_vinecuttable", R6));
var Y9 = Y8;
var YR = class iF extends R6 {};
R8(YR, "obj_controller_dw_city_big_2");
RR(YR, "kinds", R7("obj_controller_dw_city_big_2", R6));
var YY = YR;
var YM = class ia extends R6 {};
R8(YM, "obj_custommenu");
RR(YM, "kinds", R7("obj_custommenu", R6));
var YO = YM;
var YZ = class iz extends R6 {};
R8(YZ, "obj_cutscene_delaycmd");
RR(YZ, "kinds", R7("obj_cutscene_delaycmd", R6));
var YQ = YZ;
var Yf = class iH extends R6 {};
R8(Yf, "obj_cutscene_messagecmd");
RR(Yf, "kinds", R7("obj_cutscene_messagecmd", R6));
var YB = Yf;
var Yp = class iI extends R6 {};
R8(Yp, "obj_darkdoor");
RR(Yp, "kinds", R7("obj_darkdoor", R6));
var YK = Yp;
var Ym = class iC extends R6 {};
R8(Ym, "obj_darkfruit_tree_plat");
RR(Ym, "kinds", R7("obj_darkfruit_tree_plat", R6));
var YD = Ym;
var YV = class iS extends R6 {};
R8(YV, "obj_darkslide");
RR(YV, "kinds", R7("obj_darkslide", R6));
var Yh = YV;
var Yl = class iJ extends R6 {};
R8(Yl, "obj_darkslide_new");
RR(Yl, "kinds", R7("obj_darkslide_new", R6));
var Yy = Yl;
var YU = class iW extends R6 {};
R8(YU, "obj_dashmode_trigger");
RR(YU, "kinds", R7("obj_dashmode_trigger", R6));
var Yo = YU;
var YA = class ib extends R6 {};
R8(YA, "obj_diamondenemy");
RR(YA, "kinds", R7("obj_diamondenemy", R6));
var Yj = YA;
var Yw = class iE extends R6 {};
R8(Yw, "obj_dojofx");
RR(Yw, "kinds", R7("obj_dojofx", R6));
var YF = Yw;
var Ya = class ie extends R6 {};
R8(Ya, "obj_dw_cliff_kawkawdash");
RR(Ya, "kinds", R7("obj_dw_cliff_kawkawdash", R6));
var Yn = Ya;
var Yz = class iq extends R6 {};
R8(Yz, "obj_dw_cliffs_tallgrass");
RR(Yz, "kinds", R7("obj_dw_cliffs_tallgrass", R6));
var YH = Yz;
var YI = class iP extends R6 {};
R8(YI, "obj_dw_dogplatforming");
RR(YI, "kinds", R7("obj_dw_dogplatforming", R6));
var YC = YI;
var YS = class iL extends R6 {};
R8(YS, "obj_dw_fcastle_bounce_3");
RR(YS, "kinds", R7("obj_dw_fcastle_bounce_3", R6));
var YJ = YS;
var YW = class ig extends R6 {};
R8(YW, "obj_dw_fcastle_flowerclimb");
RR(YW, "kinds", R7("obj_dw_fcastle_flowerclimb", R6));
var Yb = YW;
var YE = class iv extends R6 {};
R8(YE, "obj_dw_fcastle_flowery");
RR(YE, "kinds", R7("obj_dw_fcastle_flowery", R6));
var Ye = YE;
var Yq = class iu extends R6 {};
R8(Yq, "obj_dw_fcastle_green_checkpoint");
RR(Yq, "kinds", R7("obj_dw_fcastle_green_checkpoint", R6));
var YP = Yq;
var YL = class iT extends R6 {};
R8(YL, "obj_dw_fcastle_orange_gauntlet");
RR(YL, "kinds", R7("obj_dw_fcastle_orange_gauntlet", R6));
var Yg = YL;
var Yv = class ir extends R6 {};
R8(Yv, "obj_dw_fcastle_seth_encounter");
RR(Yv, "kinds", R7("obj_dw_fcastle_seth_encounter", R6));
var Yu = Yv;
var YT = class iN extends R6 {};
R8(YT, "obj_dw_fcastle_top_ascent");
RR(YT, "kinds", R7("obj_dw_fcastle_top_ascent", R6));
var Yr = YT;
var YN = class iG extends R6 {};
R8(YN, "obj_dw_fcastle_top_challenge");
RR(YN, "kinds", R7("obj_dw_fcastle_top_challenge", R6));
var YG = YN;
var YX = class iX extends R6 {};
R8(YX, "obj_dw_fcastle_top_descent");
RR(YX, "kinds", R7("obj_dw_fcastle_top_descent", R6));
var M0 = YX;
var M1 = class p0 extends R6 {};
R8(M1, "obj_dw_fcastle_top_staircase_1");
RR(M1, "kinds", R7("obj_dw_fcastle_top_staircase_1", R6));
var M2 = M1;
var M3 = class p1 extends R6 {};
R8(M3, "obj_dw_fcastle_top_staircase_2");
RR(M3, "kinds", R7("obj_dw_fcastle_top_staircase_2", R6));
var M4 = M3;
var M5 = class p2 extends R6 {};
R8(M5, "obj_dw_fcastle_ultradash");
RR(M5, "kinds", R7("obj_dw_fcastle_ultradash", R6));
var M6 = M5;
var M7 = class p3 extends R6 {};
R8(M7, "obj_dw_fcastle_yellowblue");
RR(M7, "kinds", R7("obj_dw_fcastle_yellowblue", R6));
var M8 = M7;
var M9 = class p4 extends R6 {};
R8(M9, "obj_dw_flowery_tree");
RR(M9, "kinds", R7("obj_dw_flowery_tree", R6));
var MR = M9;
var MY = class p5 extends R6 {};
R8(MY, "obj_dw_garden_aquadash_plat");
RR(MY, "kinds", R7("obj_dw_garden_aquadash_plat", R6));
var MM = MY;
var MO = class p6 extends R6 {};
R8(MO, "obj_dw_garden_aquaplatforming");
RR(MO, "kinds", R7("obj_dw_garden_aquaplatforming", R6));
var MZ = MO;
var MQ = class p7 extends R6 {};
R8(MQ, "obj_dw_garden_enemyrush");
RR(MQ, "kinds", R7("obj_dw_garden_enemyrush", R6));
var Mf = MQ;
var MB = class p8 extends R6 {};
R8(MB, "obj_dw_leave");
RR(MB, "kinds", R7("obj_dw_leave", R6));
var Mp = MB;
var MK = class p9 extends R6 {};
R8(MK, "obj_dw_leave_flowercastle");
RR(MK, "kinds", R7("obj_dw_leave_flowercastle", R6));
var Mm = MK;
var MD = class pR extends R6 {};
R8(MD, "obj_dw_leave_flowery");
RR(MD, "kinds", R7("obj_dw_leave_flowery", R6));
var MV = MD;
var Mh = class pY extends R6 {};
R8(Mh, "obj_elevator_warp");
RR(Mh, "kinds", R7("obj_elevator_warp", R6));
var Ml = Mh;
var My = class pM extends R6 {};
R8(My, "obj_elnina_lanino_rematch_controller");
RR(My, "kinds", R7("obj_elnina_lanino_rematch_controller", R6));
var MU = My;
var Mo = class pO extends R6 {};
R8(Mo, "obj_flowery_act_menu_heart");
RR(Mo, "kinds", R7("obj_flowery_act_menu_heart", R6));
var MA = Mo;
var Mj = class pZ extends R6 {};
R8(Mj, "obj_flowery_marker");
RR(Mj, "kinds", R7("obj_flowery_marker", R6));
var Mw = Mj;
var MF = class pQ extends R6 {};
R8(MF, "obj_flowerybox_parent");
RR(MF, "kinds", R7("obj_flowerybox_parent", R6));
var Ma = MF;
var Mn = class pf extends R6 {};
R8(Mn, "obj_glowtile_new");
RR(Mn, "kinds", R7("obj_glowtile_new", R6));
var Mz = Mn;
var MH = class pB extends R6 {};
R8(MH, "obj_headhathy");
RR(MH, "kinds", R7("obj_headhathy", R6));
var MI = MH;
var MC = class pp extends R6 {};
R8(MC, "obj_heartenemy");
RR(MC, "kinds", R7("obj_heartenemy", R6));
var MS = MC;
var MJ = class pK extends R6 {};
R8(MJ, "obj_heartmarker");
RR(MJ, "kinds", R7("obj_heartmarker", R6));
var MW = MJ;
var Mb = class pm extends R6 {};
R8(Mb, "obj_heightfloor_changer");
RR(Mb, "kinds", R7("obj_heightfloor_changer", R6));
var ME = Mb;
var Me = class pD extends R6 {};
R8(Me, "obj_heronoelle");
RR(Me, "kinds", R7("obj_heronoelle", R6));
var Mq = Me;
var MP = class pV extends R6 {};
R8(MP, "obj_id");
RR(MP, "kinds", R7("obj_id", R6));
var ML = MP;
var Mg = class ph extends R6 {};
R8(Mg, "obj_index");
RR(Mg, "kinds", R7("obj_index", R6));
var Mv = Mg;
var Mu = class pl extends R6 {};
R8(Mu, "obj_interactablesolid");
RR(Mu, "kinds", R7("obj_interactablesolid", R6));
var MT = Mu;
var Mr = class py extends R6 {};
R8(Mr, "obj_jackenstein_enemy");
RR(Mr, "kinds", R7("obj_jackenstein_enemy", R6));
var MN = Mr;
var MG = class pU extends R6 {};
R8(MG, "obj_jigsawryenemy");
RR(MG, "kinds", R7("obj_jigsawryenemy", R6));
var MX = MG;
var O0 = class po extends R6 {};
R8(O0, "obj_king_boss");
RR(O0, "kinds", R7("obj_king_boss", R6));
var O1 = O0;
var O2 = class pA extends R6 {};
R8(O2, "obj_kris_headobj");
RR(O2, "kinds", R7("obj_kris_headobj", R6));
var O3 = O2;
var O4 = class pj extends R6 {};
R8(O4, "obj_lancerboss");
RR(O4, "kinds", R7("obj_lancerboss", R6));
var O5 = O4;
var O6 = class pw extends R6 {};
R8(O6, "obj_lancerboss2");
RR(O6, "kinds", R7("obj_lancerboss2", R6));
var O7 = O6;
var O8 = class pF extends R6 {};
R8(O8, "obj_lancerboss3");
RR(O8, "kinds", R7("obj_lancerboss3", R6));
var O9 = O8;
var OR = class pa extends R6 {};
R8(OR, "obj_mainchara");
RR(OR, "kinds", R7("obj_mainchara", R6));
var OY = OR;
var OM = class pn extends R6 {};
R8(OM, "obj_mainchara_dash");
RR(OM, "kinds", R7("obj_mainchara_dash", R6));
var OO = OM;
var OZ = class pz extends R6 {};
R8(OZ, "obj_maus_enemy");
RR(OZ, "kinds", R7("obj_maus_enemy", R6));
var OQ = OZ;
var Of = class pH extends R6 {};
R8(Of, "obj_move_actor");
RR(Of, "kinds", R7("obj_move_actor", R6));
var OB = Of;
var Op = class pI extends R6 {};
R8(Op, "obj_npc_cafe");
RR(Op, "kinds", R7("obj_npc_cafe", R6));
var OK = Op;
var Om = class pC extends R6 {};
R8(Om, "obj_npc_castle_cafe");
RR(Om, "kinds", R7("obj_npc_castle_cafe", R6));
var OD = Om;
var OV = class pS extends R6 {};
R8(OV, "obj_npc_castle_cliff");
RR(OV, "kinds", R7("obj_npc_castle_cliff", R6));
var Oh = OV;
var Ol = class pJ extends R6 {};
R8(Ol, "obj_npc_castle_door");
RR(Ol, "kinds", R7("obj_npc_castle_door", R6));
var Oy = Ol;
var OU = class pW extends R6 {};
R8(OU, "obj_npc_castle_town_mizzle");
RR(OU, "kinds", R7("obj_npc_castle_town_mizzle", R6));
var Oo = OU;
var OA = class pb extends R6 {};
R8(OA, "obj_npc_dojo");
RR(OA, "kinds", R7("obj_npc_dojo", R6));
var Oj = OA;
var Ow = class pE extends R6 {};
R8(Ow, "obj_npc_dumpster");
RR(Ow, "kinds", R7("obj_npc_dumpster", R6));
var OF = Ow;
var Oa = class pe extends R6 {};
R8(Oa, "obj_npc_hammerguy");
RR(Oa, "kinds", R7("obj_npc_hammerguy", R6));
var On = Oa;
var Oz = class pq extends R6 {};
R8(Oz, "obj_npc_rabbits");
RR(Oz, "kinds", R7("obj_npc_rabbits", R6));
var OH = Oz;
var OI = class pP extends R6 {};
R8(OI, "obj_npc_room");
RR(OI, "kinds", R7("obj_npc_room", R6));
var OC = OI;
var OS = class pL extends R6 {};
R8(OS, "obj_npc_sign");
RR(OS, "kinds", R7("obj_npc_sign", R6));
var OJ = OS;
var OW = class pg extends R6 {};
R8(OW, "obj_npc_tasquemanager");
RR(OW, "kinds", R7("obj_npc_tasquemanager", R6));
var Ob = OW;
var OE = class pv extends R6 {};
R8(OE, "obj_omawaroid_enemy");
RR(OE, "kinds", R7("obj_omawaroid_enemy", R6));
var Oe = OE;
var Oq = class pu extends R6 {};
R8(Oq, "obj_onion_event");
RR(Oq, "kinds", R7("obj_onion_event", R6));
var OP = Oq;
var OL = class pT extends R6 {};
R8(OL, "obj_panfancy");
RR(OL, "kinds", R7("obj_panfancy", R6));
var Og = OL;
var Ov = class pr extends R6 {};
R8(Ov, "obj_papergrass");
RR(Ov, "kinds", R7("obj_papergrass", R6));
var Ou = Ov;
var OT = class pN extends R6 {};
R8(OT, "obj_parallax_cliffs");
RR(OT, "kinds", R7("obj_parallax_cliffs", R6));
var Or = OT;
var ON = class pG extends R6 {};
R8(ON, "obj_pink_spotlight");
RR(ON, "kinds", R7("obj_pink_spotlight", R6));
var OG = ON;
var OX = class pX extends R6 {};
R8(OX, "obj_pinwheel_windspeed");
RR(OX, "kinds", R7("obj_pinwheel_windspeed", R6));
var Z0 = OX;
var Z1 = class K0 extends R6 {};
R8(Z1, "obj_plat_action_blocker");
RR(Z1, "kinds", R7("obj_plat_action_blocker", R6));
var Z2 = Z1;
var Z3 = class K1 extends R6 {};
R8(Z3, "obj_plat_action_release_trigger");
RR(Z3, "kinds", R7("obj_plat_action_release_trigger", R6));
var Z4 = Z3;
var Z5 = class K2 extends R6 {};
R8(Z5, "obj_plat_attacktrigger");
RR(Z5, "kinds", R7("obj_plat_attacktrigger", R6));
var Z6 = Z5;
var Z7 = class K3 extends R6 {};
R8(Z7, "obj_plat_blueflower");
RR(Z7, "kinds", R7("obj_plat_blueflower", R6));
var Z8 = Z7;
var Z9 = class K4 extends R6 {};
R8(Z9, "obj_plat_bulletblue_yellowhat");
RR(Z9, "kinds", R7("obj_plat_bulletblue_yellowhat", R6));
var ZR = Z9;
var ZY = class K5 extends R6 {};
R8(ZY, "obj_plat_camera");
RR(ZY, "kinds", R7("obj_plat_camera", R6));
var ZM = ZY;
var ZO = class K6 extends R6 {};
R8(ZO, "obj_plat_combatstarter");
RR(ZO, "kinds", R7("obj_plat_combatstarter", R6));
var ZZ = ZO;
var ZQ = class K7 extends R6 {};
R8(ZQ, "obj_plat_conspiracy_new");
RR(ZQ, "kinds", R7("obj_plat_conspiracy_new", R6));
var Zf = ZQ;
var ZB = class K8 extends R6 {};
R8(ZB, "obj_plat_conspiracywall");
RR(ZB, "kinds", R7("obj_plat_conspiracywall", R6));
var Zp = ZB;
var ZK = class K9 extends R6 {};
R8(ZK, "obj_plat_dialogue_sequencer");
RR(ZK, "kinds", R7("obj_plat_dialogue_sequencer", R6));
var Zm = ZK;
var ZD = class KR extends R6 {};
R8(ZD, "obj_plat_enm_aqua_bouncer");
RR(ZD, "kinds", R7("obj_plat_enm_aqua_bouncer", R6));
var ZV = ZD;
var Zh = class KY extends R6 {};
R8(Zh, "obj_plat_enm_aqua_gold");
RR(Zh, "kinds", R7("obj_plat_enm_aqua_gold", R6));
var Zl = Zh;
var Zy = class KM extends R6 {};
R8(Zy, "obj_plat_enm_aqua_small");
RR(Zy, "kinds", R7("obj_plat_enm_aqua_small", R6));
var ZU = Zy;
var Zo = class KO extends R6 {};
R8(Zo, "obj_plat_enm_aqua_sword");
RR(Zo, "kinds", R7("obj_plat_enm_aqua_sword", R6));
var ZA = Zo;
var Zj = class KZ extends R6 {};
R8(Zj, "obj_plat_enm_bigtome");
RR(Zj, "kinds", R7("obj_plat_enm_bigtome", R6));
var Zw = Zj;
var ZF = class KQ extends R6 {};
R8(ZF, "obj_plat_enm_glovespawner");
RR(ZF, "kinds", R7("obj_plat_enm_glovespawner", R6));
var Za = ZF;
var Zn = class Kf extends R6 {};
R8(Zn, "obj_plat_enm_glovespawner_directional");
RR(Zn, "kinds", R7("obj_plat_enm_glovespawner_directional", R6));
var Zz = Zn;
var ZH = class KB extends R6 {};
R8(ZH, "obj_plat_enm_yellow_punishmentgun");
RR(ZH, "kinds", R7("obj_plat_enm_yellow_punishmentgun", R6));
var ZI = ZH;
var ZC = class Kp extends R6 {};
R8(ZC, "obj_plat_enm_yellow_ufohat");
RR(ZC, "kinds", R7("obj_plat_enm_yellow_ufohat", R6));
var ZS = ZC;
var ZJ = class KK extends R6 {};
R8(ZJ, "obj_plat_finalflowery");
RR(ZJ, "kinds", R7("obj_plat_finalflowery", R6));
var ZW = ZJ;
var Zb = class Km extends R6 {};
R8(Zb, "obj_plat_floortex");
RR(Zb, "kinds", R7("obj_plat_floortex", R6));
var ZE = Zb;
var Ze = class KD extends R6 {};
R8(Ze, "obj_plat_floortex_FLOOR");
RR(Ze, "kinds", R7("obj_plat_floortex_FLOOR", R6));
var Zq = Ze;
var ZP = class KV extends R6 {};
R8(ZP, "obj_plat_follower");
RR(ZP, "kinds", R7("obj_plat_follower", R6));
var ZL = ZP;
var Zg = class Kh extends R6 {};
R8(Zg, "obj_plat_fusumawall");
RR(Zg, "kinds", R7("obj_plat_fusumawall", R6));
var Zv = Zg;
var Zu = class Kl extends R6 {};
R8(Zu, "obj_plat_game");
RR(Zu, "kinds", R7("obj_plat_game", R6));
var ZT = Zu;
var Zr = class Ky extends R6 {};
R8(Zr, "obj_plat_hanging_key");
RR(Zr, "kinds", R7("obj_plat_hanging_key", R6));
var ZN = Zr;
var ZG = class KU extends R6 {};
R8(ZG, "obj_plat_lantern");
RR(ZG, "kinds", R7("obj_plat_lantern", R6));
var ZX = ZG;
var Q0 = class Ko extends R6 {};
R8(Q0, "obj_plat_loopboundary");
RR(Q0, "kinds", R7("obj_plat_loopboundary", R6));
var Q1 = Q0;
var Q2 = class KA extends R6 {};
R8(Q2, "obj_plat_movemarker");
RR(Q2, "kinds", R7("obj_plat_movemarker", R6));
var Q3 = Q2;
var Q4 = class Kj extends R6 {};
R8(Q4, "obj_plat_orangewall");
RR(Q4, "kinds", R7("obj_plat_orangewall", R6));
var Q5 = Q4;
var Q6 = class Kw extends R6 {};
R8(Q6, "obj_plat_pinatabell");
RR(Q6, "kinds", R7("obj_plat_pinatabell", R6));
var Q7 = Q6;
var Q8 = class KF extends R6 {};
R8(Q8, "obj_plat_pinatabell_pink");
RR(Q8, "kinds", R7("obj_plat_pinatabell_pink", R6));
var Q9 = Q8;
var QR = class Ka extends R6 {};
R8(QR, "obj_plat_player");
RR(QR, "kinds", R7("obj_plat_player", R6));
var QY = QR;
var QM = class Kn extends R6 {};
R8(QM, "obj_plat_playerheart");
RR(QM, "kinds", R7("obj_plat_playerheart", R6));
var QO = QM;
var QZ = class Kz extends R6 {};
R8(QZ, "obj_plat_sequence_marker");
RR(QZ, "kinds", R7("obj_plat_sequence_marker", R6));
var QQ = QZ;
var Qf = class KH extends R6 {};
R8(Qf, "obj_plat_shinobeetle");
RR(Qf, "kinds", R7("obj_plat_shinobeetle", R6));
var QB = Qf;
var Qp = class KI extends R6 {};
R8(Qp, "obj_plat_slope");
RR(Qp, "kinds", R7("obj_plat_slope", R6));
var QK = Qp;
var Qm = class KC extends R6 {};
R8(Qm, "obj_plat_slope_runner");
RR(Qm, "kinds", R7("obj_plat_slope_runner", R6));
var QD = Qm;
var QV = class KS extends R6 {};
R8(QV, "obj_plat_stringed_object");
RR(QV, "kinds", R7("obj_plat_stringed_object", R6));
var Qh = QV;
var Ql = class KJ extends R6 {};
R8(Ql, "obj_plat_susieaxe_hbx");
RR(Ql, "kinds", R7("obj_plat_susieaxe_hbx", R6));
var Qy = Ql;
var QU = class KW extends R6 {};
R8(QU, "obj_plat_text_at_bottom_zone");
RR(QU, "kinds", R7("obj_plat_text_at_bottom_zone", R6));
var Qo = QU;
var QA = class Kb extends R6 {};
R8(QA, "obj_plat_toyrope");
RR(QA, "kinds", R7("obj_plat_toyrope", R6));
var Qj = QA;
var Qw = class KE extends R6 {};
R8(Qw, "obj_plat_wind");
RR(Qw, "kinds", R7("obj_plat_wind", R6));
var QF = Qw;
var Qa = class Ke extends R6 {};
R8(Qa, "obj_platswap");
RR(Qa, "kinds", R7("obj_platswap", R6));
var Qn = Qa;
var Qz = class Kq extends R6 {};
R8(Qz, "obj_platswap_statue");
RR(Qz, "kinds", R7("obj_platswap_statue", R6));
var QH = Qz;
var QI = class KP extends R6 {};
R8(QI, "obj_poppup_enemy");
RR(QI, "kinds", R7("obj_poppup_enemy", R6));
var QC = QI;
var QS = class KL extends R6 {};
R8(QS, "obj_rabbick_enemy");
RR(QS, "kinds", R7("obj_rabbick_enemy", R6));
var QJ = QS;
var QW = class Kg extends R6 {};
R8(QW, "obj_room_alphysclass");
RR(QW, "kinds", R7("obj_room_alphysclass", R6));
var Qb = QW;
var QE = class Kv extends R6 {};
R8(QE, "obj_room_castle_dojo");
RR(QE, "kinds", R7("obj_room_castle_dojo", R6));
var Qe = QE;
var Qq = class Ku extends R6 {};
R8(Qq, "obj_room_castle_front_race");
RR(Qq, "kinds", R7("obj_room_castle_front_race", R6));
var QP = Qq;
var QL = class KT extends R6 {};
R8(QL, "obj_room_castle_front_racer");
RR(QL, "kinds", R7("obj_room_castle_front_racer", R6));
var Qg = QL;
var Qv = class Kr extends R6 {};
R8(Qv, "obj_room_castle_kris");
RR(Qv, "kinds", R7("obj_room_castle_kris", R6));
var Qu = Qv;
var QT = class KN extends R6 {};
R8(QT, "obj_room_castle_music");
RR(QT, "kinds", R7("obj_room_castle_music", R6));
var Qr = QT;
var QN = class KG extends R6 {};
R8(QN, "obj_room_castle_ralsei");
RR(QN, "kinds", R7("obj_room_castle_ralsei", R6));
var QG = QN;
var QX = class KX extends R6 {};
R8(QX, "obj_room_castle_susie");
RR(QX, "kinds", R7("obj_room_castle_susie", R6));
var f0 = QX;
var f1 = class m0 extends R6 {};
R8(f1, "obj_room_castle_tv_kikky");
RR(f1, "kinds", R7("obj_room_castle_tv_kikky", R6));
var f2 = f1;
var f3 = class m1 extends R6 {};
R8(f3, "obj_room_castle_tv_mike");
RR(f3, "kinds", R7("obj_room_castle_tv_mike", R6));
var f4 = f3;
var f5 = class m2 extends R6 {};
R8(f5, "obj_room_castle_tv_rhythm");
RR(f5, "kinds", R7("obj_room_castle_tv_rhythm", R6));
var f6 = f5;
var f7 = class m3 extends R6 {};
R8(f7, "obj_room_krisroom");
RR(f7, "kinds", R7("obj_room_krisroom", R6));
var f8 = f7;
var f9 = class m4 extends R6 {};
R8(f9, "obj_room_torbathroom");
RR(f9, "kinds", R7("obj_room_torbathroom", R6));
var fR = f9;
var fY = class m5 extends R6 {};
R8(fY, "obj_room_torhouse");
RR(fY, "kinds", R7("obj_room_torhouse", R6));
var fM = fY;
var fO = class m6 extends R6 {};
R8(fO, "obj_room_town_church");
RR(fO, "kinds", R7("obj_room_town_church", R6));
var fZ = fO;
var fQ = class m7 extends R6 {};
R8(fQ, "obj_room_town_krisyard");
RR(fQ, "kinds", R7("obj_room_town_krisyard", R6));
var ff = fQ;
var fB = class m8 extends R6 {};
R8(fB, "obj_room_town_mid_diner");
RR(fB, "kinds", R7("obj_room_town_mid_diner", R6));
var fp = fB;
var fK = class m9 extends R6 {};
R8(fK, "obj_room_town_school");
RR(fK, "kinds", R7("obj_room_town_school", R6));
var fm = fK;
var fD = class mR extends R6 {};
R8(fD, "obj_rotating_tower_controller_new");
RR(fD, "kinds", R7("obj_rotating_tower_controller_new", R6));
var fV = fD;
var fh = class mY extends R6 {};
R8(fh, "obj_scissor_flower_chaser_scissor");
RR(fh, "kinds", R7("obj_scissor_flower_chaser_scissor", R6));
var fl = fh;
var fy = class mM extends R6 {};
R8(fy, "obj_scissordancer");
RR(fy, "kinds", R7("obj_scissordancer", R6));
var fU = fy;
var fo = class mO extends R6 {};
R8(fo, "obj_shinobeetle_star");
RR(fo, "kinds", R7("obj_shinobeetle_star", R6));
var fA = fo;
var fj = class mZ extends R6 {};
R8(fj, "obj_smallcheckers_enemy");
RR(fj, "kinds", R7("obj_smallcheckers_enemy", R6));
var fw = fj;
var fF = class mQ extends R6 {};
R8(fF, "obj_smalldough");
RR(fF, "kinds", R7("obj_smalldough", R6));
var fa = fF;
var fn = class mf extends R6 {};
R8(fn, "obj_soliddark");
RR(fn, "kinds", R7("obj_soliddark", R6));
var fz = fn;
var fH = class mB extends R6 {};
R8(fH, "obj_solidenemy");
RR(fH, "kinds", R7("obj_solidenemy", R6));
var fI = fH;
var fC = class mp extends R6 {};
R8(fC, "obj_solidenemy_2");
RR(fC, "kinds", R7("obj_solidenemy_2", R6));
var fS = fC;
var fJ = class mK extends R6 {};
R8(fJ, "obj_sourdough");
RR(fJ, "kinds", R7("obj_sourdough", R6));
var fW = fJ;
var fb = class mm extends R6 {};
R8(fb, "obj_spwnY");
RR(fb, "kinds", R7("obj_spwnY", R6));
var fE = fb;
var fe = class mD extends R6 {};
R8(fe, "obj_starwalker_offswitch");
RR(fe, "kinds", R7("obj_starwalker_offswitch", R6));
var fq = fe;
var fP = class mV extends R6 {};
R8(fP, "obj_stickto");
RR(fP, "kinds", R7("obj_stickto", R6));
var fL = fP;
var fg = class mh extends R6 {};
R8(fg, "obj_sticky_example");
RR(fg, "kinds", R7("obj_sticky_example", R6));
var fv = fg;
var fu = class ml extends R6 {};
R8(fu, "obj_sunshadows");
RR(fu, "kinds", R7("obj_sunshadows", R6));
var fT = fu;
var fr = class my extends R6 {};
R8(fr, "obj_susieenemy");
RR(fr, "kinds", R7("obj_susieenemy", R6));
var fN = fr;
var fG = class mU extends R6 {};
R8(fG, "obj_swatchling_enemy");
RR(fG, "kinds", R7("obj_swatchling_enemy", R6));
var fX = fG;
var B0 = class mo extends R6 {};
R8(B0, "obj_swordhitbox");
RR(B0, "kinds", R7("obj_swordhitbox", R6));
var B1 = B0;
var B2 = class mA extends R6 {};
R8(B2, "obj_tasque_enemy");
RR(B2, "kinds", R7("obj_tasque_enemy", R6));
var B3 = B2;
var B4 = class mj extends R6 {};
R8(B4, "obj_tm_quiz_result");
RR(B4, "kinds", R7("obj_tm_quiz_result", R6));
var B5 = B4;
var B6 = class mw extends R6 {};
R8(B6, "obj_torigate");
RR(B6, "kinds", R7("obj_torigate", R6));
var B7 = B6;
var B8 = class mF extends R6 {};
R8(B8, "obj_towery_orbiter");
RR(B8, "kinds", R7("obj_towery_orbiter", R6));
var B9 = B8;
var BR = class ma extends R6 {};
R8(BR, "obj_town_church_rudy");
RR(BR, "kinds", R7("obj_town_church_rudy", R6));
var BY = BR;
var BM = class mn extends R6 {};
R8(BM, "obj_town_mid_conbini");
RR(BM, "kinds", R7("obj_town_mid_conbini", R6));
var BO = BM;
var BZ = class mz extends R6 {};
R8(BZ, "obj_town_mid_doors");
RR(BZ, "kinds", R7("obj_town_mid_doors", R6));
var BQ = BZ;
var Bf = class mH extends R6 {};
R8(Bf, "obj_town_mid_ferris");
RR(Bf, "kinds", R7("obj_town_mid_ferris", R6));
var BB = Bf;
var Bp = class mI extends R6 {};
R8(Bp, "obj_town_mid_ferris_w");
RR(Bp, "kinds", R7("obj_town_mid_ferris_w", R6));
var BK = Bp;
var Bm = class mC extends R6 {};
R8(Bm, "obj_town_mid_sans");
RR(Bm, "kinds", R7("obj_town_mid_sans", R6));
var BD = Bm;
var BV = class mS extends R6 {};
R8(BV, "obj_town_mid_sans_w");
RR(BV, "kinds", R7("obj_town_mid_sans_w", R6));
var Bh = BV;
var Bl = class mJ extends R6 {};
R8(Bl, "obj_town_mid_teacup");
RR(Bl, "kinds", R7("obj_town_mid_teacup", R6));
var By = Bl;
var BU = class mW extends R6 {};
R8(BU, "obj_town_mid_temmie");
RR(BU, "kinds", R7("obj_town_mid_temmie", R6));
var Bo = BU;
var BA = class mb extends R6 {};
R8(BA, "obj_town_north");
RR(BA, "kinds", R7("obj_town_north", R6));
var Bj = BA;
var Bw = class mE extends R6 {};
R8(Bw, "obj_town_north_asgore");
RR(Bw, "kinds", R7("obj_town_north_asgore", R6));
var BF = Bw;
var Ba = class me extends R6 {};
R8(Ba, "obj_town_north_catty_house");
RR(Ba, "kinds", R7("obj_town_north_catty_house", R6));
var Bn = Ba;
var Bz = class mq extends R6 {};
R8(Bz, "obj_town_north_napstablook");
RR(Bz, "kinds", R7("obj_town_north_napstablook", R6));
var BH = Bz;
var BI = class mP extends R6 {};
R8(BI, "obj_town_south_dunk_tank");
RR(BI, "kinds", R7("obj_town_south_dunk_tank", R6));
var BC = BI;
var BS = class mL extends R6 {};
R8(BS, "obj_town_south_strength");
RR(BS, "kinds", R7("obj_town_south_strength", R6));
var BJ = BS;
var BW = class mg extends R6 {};
R8(BW, "obj_town_south_tako");
RR(BW, "kinds", R7("obj_town_south_tako", R6));
var Bb = BW;
var BE = class mv extends R6 {};
R8(BE, "obj_town_w_shining");
RR(BE, "kinds", R7("obj_town_w_shining", R6));
var Be = BE;
var Bq = class mu extends R6 {};
R8(Bq, "obj_virovirokun_enemy");
RR(Bq, "kinds", R7("obj_virovirokun_enemy", R6));
var BP = Bq;
var BL = class mT extends R6 {};
R8(BL, "obj_werewerewire_enemy");
RR(BL, "kinds", R7("obj_werewerewire_enemy", R6));
var Bg = BL;
var Bv = class mr extends R6 {};
R8(Bv, "obj_werewerewire_laserbullet");
RR(Bv, "kinds", R7("obj_werewerewire_laserbullet", R6));
var Bu = Bv;
var BT = class mN extends R6 {};
R8(BT, "obj_werewire_enemy");
RR(BT, "kinds", R7("obj_werewire_enemy", R6));
var Br = BT;
var BN = class mG extends R6 {};
R8(BN, "obj_yheart_shot");
RR(BN, "kinds", R7("obj_yheart_shot", R6));
var BG = BN;
export {
  RZ as a,
  Rf as b,
  Rp as c,
  Rm as d,
  RV as e,
  Rl as f,
  RU as g,
  RA as h,
  Rw as i,
  Ra as j,
  Rz as k,
  RI as l,
  RS as m,
  RW as n,
  RE as o,
  Rq as p,
  RL as q,
  Rv as r,
  RT as s,
  RN as t,
  RX as u,
  Y1 as v,
  Y3 as w,
  Y5 as x,
  Y7 as y,
  Y9 as z,
  YY as A,
  YO as B,
  YQ as C,
  YB as D,
  YK as E,
  YD as F,
  Yh as G,
  Yy as H,
  Yo as I,
  Yj as J,
  YF as K,
  Yn as L,
  YH as M,
  YC as N,
  YJ as O,
  Yb as P,
  Ye as Q,
  YP as R,
  Yg as S,
  Yu as T,
  Yr as U,
  YG as V,
  M0 as W,
  M2 as X,
  M4 as Y,
  M6 as Z,
  M8 as _,
  MR as $,
  MM as aa,
  MZ as ba,
  Mf as ca,
  Mp as da,
  Mm as ea,
  MV as fa,
  Ml as ga,
  MU as ha,
  MA as ia,
  Mw as ja,
  Ma as ka,
  Mz as la,
  MI as ma,
  MS as na,
  MW as oa,
  ME as pa,
  Mq as qa,
  ML as ra,
  Mv as sa,
  MT as ta,
  MN as ua,
  MX as va,
  O1 as wa,
  O3 as xa,
  O5 as ya,
  O7 as za,
  O9 as Aa,
  OY as Ba,
  OO as Ca,
  OQ as Da,
  OB as Ea,
  OK as Fa,
  OD as Ga,
  Oh as Ha,
  Oy as Ia,
  Oo as Ja,
  Oj as Ka,
  OF as La,
  On as Ma,
  OH as Na,
  OC as Oa,
  OJ as Pa,
  Ob as Qa,
  Oe as Ra,
  OP as Sa,
  Og as Ta,
  Ou as Ua,
  Or as Va,
  OG as Wa,
  Z0 as Xa,
  Z2 as Ya,
  Z4 as Za,
  Z6 as _a,
  Z8 as $a,
  ZR as ab,
  ZM as bb,
  ZZ as cb,
  Zf as db,
  Zp as eb,
  Zm as fb,
  ZV as gb,
  Zl as hb,
  ZU as ib,
  ZA as jb,
  Zw as kb,
  Za as lb,
  Zz as mb,
  ZI as nb,
  ZS as ob,
  ZW as pb,
  ZE as qb,
  Zq as rb,
  ZL as sb,
  Zv as tb,
  ZT as ub,
  ZN as vb,
  ZX as wb,
  Q1 as xb,
  Q3 as yb,
  Q5 as zb,
  Q7 as Ab,
  Q9 as Bb,
  QY as Cb,
  QO as Db,
  QQ as Eb,
  QB as Fb,
  QK as Gb,
  QD as Hb,
  Qh as Ib,
  Qy as Jb,
  Qo as Kb,
  Qj as Lb,
  QF as Mb,
  Qn as Nb,
  QH as Ob,
  QC as Pb,
  QJ as Qb,
  Qb as Rb,
  Qe as Sb,
  QP as Tb,
  Qg as Ub,
  Qu as Vb,
  Qr as Wb,
  QG as Xb,
  f0 as Yb,
  f2 as Zb,
  f4 as _b,
  f6 as $b,
  f8 as ac,
  fR as bc,
  fM as cc,
  fZ as dc,
  ff as ec,
  fp as fc,
  fm as gc,
  fV as hc,
  fl as ic,
  fU as jc,
  fA as kc,
  fw as lc,
  fa as mc,
  fz as nc,
  fI as oc,
  fS as pc,
  fW as qc,
  fE as rc,
  fq as sc,
  fL as tc,
  fv as uc,
  fT as vc,
  fN as wc,
  fX as xc,
  B1 as yc,
  B3 as zc,
  B5 as Ac,
  B7 as Bc,
  B9 as Cc,
  BY as Dc,
  BO as Ec,
  BQ as Fc,
  BB as Gc,
  BK as Hc,
  BD as Ic,
  Bh as Jc,
  By as Kc,
  Bo as Lc,
  Bj as Mc,
  BF as Nc,
  Bn as Oc,
  BH as Pc,
  BC as Qc,
  BJ as Rc,
  Bb as Sc,
  Be as Tc,
  BP as Uc,
  Bg as Vc,
  Bu as Wc,
  Br as Xc,
  BG as Yc,
  RM as Zc,
};
